class StartPage extends Base {

  render() {
    return /*html*/`
      <div class="row" route="/" page-title="Start">
        <div class="col-12">
          <h1>Start page</h1>
          <p>This is the start page.</p>
        </div>
      </div>
    `;
  }

}