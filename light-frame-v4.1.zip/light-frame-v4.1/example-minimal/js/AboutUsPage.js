class AboutUsPage extends Base {

  render() {
    return /*html*/`
      <div class="row" route="/about-us" page-title="About us">
        <div class="col-12">
          <h1>About us</h1>
          <p>This is a page about us.</p>
        </div>
      </div>
    `;
  }

}