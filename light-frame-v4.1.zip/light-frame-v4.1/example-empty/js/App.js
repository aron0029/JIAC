class App extends Base {

  render() {
    return /*html*/`
      <div>
        <h1>Hello world!</h1>
      </div>
    `;
  }

}