let open = require('open');
open('https://github.com/pawelsalawa/sqlitestudio/releases');